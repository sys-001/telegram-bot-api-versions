<?php

namespace TelegramApi\Types;

class MessageEntity implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the entity. One of mention (@username), hashtag, bot_command, url, email, bold (bold text), italic (italic text), code (monowidth string), pre (monowidth block), text_link (for clickable text URLs) */
	public string $type;

	/** @var int Offset in UTF-16 code units to the start of the entity */
	public int $offset;

	/** @var int Length of the entity in UTF-16 code units */
	public int $length;

	/** @var string|null Optional. For “text_link” only, url that will be opened after user taps on the text */
	public ?string $url = null;
}
