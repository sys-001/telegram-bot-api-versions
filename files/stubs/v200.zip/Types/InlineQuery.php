<?php

namespace TelegramApi\Types;

class InlineQuery implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this query */
	public string $id;

	/** @var User Sender */
	public User $from;

	/** @var Location|null Optional. Sender location, only for bots that request user location */
	public ?Location $location = null;

	/** @var string Text of the query */
	public string $query;

	/** @var string Offset of the results to be returned, can be controlled by the bot */
	public string $offset;
}
