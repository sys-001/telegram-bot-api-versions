<?php

namespace TelegramApi\Types;

class InputVenueMessageContent extends InputMessageContent
{
	/** @var float */
	public float $latitude;

	/** @var float */
	public float $longitude;

	/** @var string */
	public string $title;

	/** @var string */
	public string $address;

	/** @var string|null */
	public ?string $foursquareId = null;
}
