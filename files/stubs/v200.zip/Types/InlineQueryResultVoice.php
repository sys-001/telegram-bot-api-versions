<?php

namespace TelegramApi\Types;

class InlineQueryResultVoice implements TypeInterface
{
	/** @var string */
	public string $type;

	/** @var string */
	public string $id;

	/** @var string */
	public string $voiceUrl;

	/** @var string */
	public string $title;

	/** @var int|null */
	public ?int $voiceDuration = null;

	/** @var InlineKeyboardMarkup|null */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null */
	public ?InputMessageContent $inputMessageContent = null;
}
