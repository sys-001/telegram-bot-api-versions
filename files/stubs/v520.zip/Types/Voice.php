<?php

namespace TelegramApi\Types;

class Voice implements TypeInterface
{
	/** @var string Identifier for this file, which can be used to download or reuse the file */
	public string $fileId;

	/** @var string Unique identifier for this file, which is supposed to be the same over time and for different bots. Can't be used to download or reuse the file. */
	public string $fileUniqueId;

	/** @var int Duration of the audio in seconds as defined by sender */
	public int $duration;

	/** @var string|null Optional. MIME type of the file as defined by sender */
	public ?string $mimeType = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
