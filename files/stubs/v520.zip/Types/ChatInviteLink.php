<?php

namespace TelegramApi\Types;

class ChatInviteLink implements TypeInterface
{
	/** @var string */
	public string $inviteLink;

	/** @var User */
	public User $creator;

	/** @var bool */
	public bool $isPrimary;

	/** @var bool */
	public bool $isRevoked;

	/** @var int|null */
	public ?int $expireDate = null;

	/** @var int|null */
	public ?int $memberLimit = null;
}
