<?php

namespace TelegramApi\Types;

class InlineQueryResultGif extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be gif */
	public string $type = 'gif';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid URL for the GIF file. File size must not exceed 1MB */
	public string $gifUrl;

	/** @var int|null Optional. Width of the GIF */
	public ?int $gifWidth = null;

	/** @var int|null Optional. Height of the GIF */
	public ?int $gifHeight = null;

	/** @var string URL of the static thumbnail for the result (jpeg or gif) */
	public string $thumbUrl;

	/** @var string|null Optional. Title for the result */
	public ?string $title = null;

	/** @var string|null Optional. Caption of the GIF file to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var string|null Optional. Text of a message to be sent instead of the animation, 1-512 characters */
	public ?string $messageText = null;

	/** @var string|null Optional. Send Markdown or HTML, if you want Telegram apps to show bold, italic, fixed-width text or inline URLs in your bot's message. */
	public ?string $parseMode = null;

	/** @var bool|null Optional. Disables link previews for links in the sent message */
	public ?bool $disableWebPagePreview = null;
}
