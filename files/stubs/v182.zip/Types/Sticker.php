<?php

namespace TelegramApi\Types;

class Sticker implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Sticker width */
	public int $width;

	/** @var int Sticker height */
	public int $height;

	/** @var PhotoSize|null Optional. Sticker thumbnail in .webp or .jpg format */
	public ?PhotoSize $thumb = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
