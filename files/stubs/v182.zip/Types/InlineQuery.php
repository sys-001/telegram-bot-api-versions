<?php

namespace TelegramApi\Types;

class InlineQuery implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this query */
	public string $id;

	/** @var User Sender */
	public User $from;

	/** @var string Text of the query */
	public string $query;

	/** @var string Offset of the results to be returned, can be controlled by the bot */
	public string $offset;
}
