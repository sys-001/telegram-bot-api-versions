<?php

namespace TelegramApi\Types;

class ChosenInlineResult implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string The unique identifier for the result that was chosen. */
	public string $resultId;

	/** @var User The user that chose the result. */
	public User $from;

	/** @var string The query that was used to obtain the result. */
	public string $query;
}
