<?php

namespace TelegramApi\Types;

class InlineQueryResultDocument extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be document */
	public string $type = 'document';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string Title for the result */
	public string $title;

	/** @var string|null Optional. Caption of the document to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var string A valid URL for the file */
	public string $documentUrl;

	/** @var string Mime type of the content of the file, either “application/pdf” or “application/zip” */
	public string $mimeType;

	/** @var string|null Optional. Short description of the result */
	public ?string $description = null;

	/** @var InlineKeyboardMarkup|null Optional. Inline keyboard attached to the message */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null Optional. Content of the message to be sent instead of the file */
	public ?InputMessageContent $inputMessageContent = null;

	/** @var string|null Optional. URL of the thumbnail (jpeg only) for the file */
	public ?string $thumbUrl = null;

	/** @var int|null Optional. Thumbnail width */
	public ?int $thumbWidth = null;

	/** @var int|null Optional. Thumbnail height */
	public ?int $thumbHeight = null;
}
