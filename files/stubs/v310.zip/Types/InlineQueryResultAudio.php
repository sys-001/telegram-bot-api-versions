<?php

namespace TelegramApi\Types;

class InlineQueryResultAudio extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be audio */
	public string $type = 'audio';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid URL for the audio file */
	public string $audioUrl;

	/** @var string Title */
	public string $title;

	/** @var string|null Optional. Caption, 0-200 characters */
	public ?string $caption = null;

	/** @var string|null Optional. Performer */
	public ?string $performer = null;

	/** @var int|null Optional. Audio duration in seconds */
	public ?int $audioDuration = null;

	/** @var InlineKeyboardMarkup|null Optional. Inline keyboard attached to the message */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null Optional. Content of the message to be sent instead of the audio */
	public ?InputMessageContent $inputMessageContent = null;
}
