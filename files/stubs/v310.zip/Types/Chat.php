<?php

namespace TelegramApi\Types;

class Chat implements TypeInterface
{
	/** @var int */
	public int $id;

	/** @var string */
	public string $type;

	/** @var string|null */
	public ?string $title = null;

	/** @var string|null */
	public ?string $username = null;

	/** @var string|null */
	public ?string $firstName = null;

	/** @var string|null */
	public ?string $lastName = null;

	/** @var bool|null */
	public ?bool $allMembersAreAdministrators = null;

	/** @var ChatPhoto|null */
	public ?ChatPhoto $photo = null;

	/** @var string|null */
	public ?string $description = null;

	/** @var string|null */
	public ?string $inviteLink = null;
}
