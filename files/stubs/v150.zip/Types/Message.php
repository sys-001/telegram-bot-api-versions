<?php

namespace TelegramApi\Types;

class Message implements TypeInterface
{
	/** @var int */
	public int $messageId;

	/** @var User */
	public User $from;

	/** @var int */
	public int $date;

	/** @var User|GroupChat */
	public User|GroupChat $chat;

	/** @var User|null */
	public ?User $forwardFrom = null;

	/** @var int|null */
	public ?int $forwardDate = null;

	/** @var Message|null */
	public ?Message $replyToMessage = null;

	/** @var string|null */
	public ?string $text = null;

	/** @var Audio|null */
	public ?Audio $audio = null;

	/** @var Document|null */
	public ?Document $document = null;

	/** @var Array<PhotoSize>|null */
	public ?array $photo = null;

	/** @var Sticker|null */
	public ?Sticker $sticker = null;

	/** @var Video|null */
	public ?Video $video = null;

	/** @var Voice|null */
	public ?Voice $voice = null;

	/** @var string|null */
	public ?string $caption = null;

	/** @var Contact|null */
	public ?Contact $contact = null;

	/** @var Location|null */
	public ?Location $location = null;

	/** @var User|null */
	public ?User $newChatParticipant = null;

	/** @var User|null */
	public ?User $leftChatParticipant = null;

	/** @var string|null */
	public ?string $newChatTitle = null;

	/** @var Array<PhotoSize>|null */
	public ?array $newChatPhoto = null;

	/** @var bool|null */
	public ?bool $deleteChatPhoto = null;

	/** @var bool|null */
	public ?bool $groupChatCreated = null;
}
