<?php

namespace TelegramApi\Types;

abstract class BotCommandScope implements TypeInterface
{
}
