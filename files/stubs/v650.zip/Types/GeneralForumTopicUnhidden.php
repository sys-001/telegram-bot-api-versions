<?php

namespace TelegramApi\Types;

class GeneralForumTopicUnhidden implements TypeInterface
{
}
