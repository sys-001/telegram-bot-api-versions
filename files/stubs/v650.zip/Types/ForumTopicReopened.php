<?php

namespace TelegramApi\Types;

class ForumTopicReopened implements TypeInterface
{
}
