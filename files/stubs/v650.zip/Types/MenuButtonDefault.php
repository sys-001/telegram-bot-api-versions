<?php

namespace TelegramApi\Types;

class MenuButtonDefault extends MenuButton
{
	/** @var string Type of the button, must be default */
	public string $type = 'default';
}
