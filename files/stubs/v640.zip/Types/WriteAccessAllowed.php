<?php

namespace TelegramApi\Types;

class WriteAccessAllowed implements TypeInterface
{
}
