<?php

namespace TelegramApi\Types;

class VoiceChatEnded implements TypeInterface
{
	/** @var int Voice chat duration; in seconds */
	public int $duration;
}
