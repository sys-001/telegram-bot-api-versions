<?php

namespace TelegramApi\Types;

class PhotoSize implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var string */
	public string $fileUniqueId;

	/** @var int */
	public int $width;

	/** @var int */
	public int $height;

	/** @var int|null */
	public ?int $fileSize = null;
}
