<?php

namespace TelegramApi\Types;

class BotCommandScopeDefault extends BotCommandScope
{
	/** @var string */
	public string $type;
}
