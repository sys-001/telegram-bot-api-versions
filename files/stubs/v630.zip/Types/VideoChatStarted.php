<?php

namespace TelegramApi\Types;

class VideoChatStarted implements TypeInterface
{
}
