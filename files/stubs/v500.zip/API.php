<?php

/**
 * @noinspection PhpUnused
 * @noinspection PhpUnusedParameterInspection
 */

namespace TelegramApi;

use TelegramApi\Types\Chat;
use TelegramApi\Types\ChatPermissions;
use TelegramApi\Types\File;
use TelegramApi\Types\ForceReply;
use TelegramApi\Types\InlineKeyboardMarkup;
use TelegramApi\Types\InputFile;
use TelegramApi\Types\InputMedia;
use TelegramApi\Types\MaskPosition;
use TelegramApi\Types\Message;
use TelegramApi\Types\Poll;
use TelegramApi\Types\ReplyKeyboardMarkup;
use TelegramApi\Types\ReplyKeyboardRemove;
use TelegramApi\Types\User;
use TelegramApi\Types\UserProfilePhotos;

trait API
{
	abstract public function sendRequest(string $method, array $args): mixed;


	public function getMe(): User
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function logOut(): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function close(): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageLiveLocation(
		float $latitude,
		float $longitude,
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?float $horizontalAccuracy = null,
		?int $heading = null,
		?int $proximityAlertRadius = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function stopMessageLiveLocation(
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function sendPoll(
		int|string $chatId,
		string $question,
		array $options,
		?bool $isAnonymous = null,
		?string $type = null,
		?bool $allowsMultipleAnswers = null,
		?int $correctOptionId = null,
		?string $explanation = null,
		?string $explanationParseMode = null,
		?array $explanationEntities = null,
		?int $openPeriod = null,
		?int $closeDate = null,
		?bool $isClosed = null,
		?bool $disableNotification = null,
		?int $replyToMessageId = null,
		?bool $allowSendingWithoutReply = null,
		InlineKeyboardMarkup|ReplyKeyboardMarkup|ReplyKeyboardRemove|ForceReply|null $replyMarkup = null
	): Message {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function sendDice(
		int|string $chatId,
		?string $emoji = null,
		?bool $disableNotification = null,
		?int $replyToMessageId = null,
		?bool $allowSendingWithoutReply = null,
		InlineKeyboardMarkup|ReplyKeyboardMarkup|ReplyKeyboardRemove|ForceReply|null $replyMarkup = null
	): Message {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getUserProfilePhotos(int $userId, ?int $offset = null, ?int $limit = null): UserProfilePhotos
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getFile(string $fileId): File
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function restrictChatMember(
		int|string $chatId,
		int $userId,
		ChatPermissions $permissions,
		?int $untilDate = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function setChatPermissions(int|string $chatId, ChatPermissions $permissions): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function exportChatInviteLink(int|string $chatId): string
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function setChatDescription(int|string $chatId, ?string $description = null): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function unpinChatMessage(int|string $chatId, ?int $messageId = null): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function unpinAllChatMessages(int|string $chatId): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChat(int|string $chatId): Chat
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChatAdministrators(int|string $chatId): array
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChatMembersCount(int|string $chatId): int
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function deleteChatStickerSet(int|string $chatId): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerCallbackQuery(
		string $callbackQueryId,
		?string $text = null,
		?bool $showAlert = null,
		?string $url = null,
		?int $cacheTime = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageCaption(
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?string $caption = null,
		?string $parseMode = null,
		?array $captionEntities = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageMedia(
		InputMedia $media,
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageReplyMarkup(
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function stopPoll(int|string $chatId, int $messageId, ?InlineKeyboardMarkup $replyMarkup = null): Poll
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function createNewStickerSet(
		int $userId,
		string $name,
		string $title,
		string $emojis,
		InputFile|string|null $pngSticker = null,
		?InputFile $tgsSticker = null,
		?bool $containsMasks = null,
		?MaskPosition $maskPosition = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function setStickerPositionInSet(string $sticker, int $position): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function deleteStickerFromSet(string $sticker): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function setStickerSetThumb(string $name, int $userId, InputFile|string|null $thumb = null): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerShippingQuery(
		string $shippingQueryId,
		bool $ok,
		?array $shippingOptions = null,
		?string $errorMessage = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerPreCheckoutQuery(string $preCheckoutQueryId, bool $ok, ?string $errorMessage = null): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function setPassportDataErrors(int $userId, array $errors): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function sendGame(
		int $chatId,
		string $gameShortName,
		?bool $disableNotification = null,
		?int $replyToMessageId = null,
		?bool $allowSendingWithoutReply = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}
}
