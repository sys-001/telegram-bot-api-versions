<?php

namespace TelegramApi\Types;

class Chat implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique identifier for this chat. This number may be greater than 32 bits and some programming languages may have difficulty/silent defects in interpreting it. But it smaller than 52 bits, so a signed 64 bit integer or double-precision float type are safe for storing this identifier. */
	public int $id;

	/** @var string Type of chat, can be either “private”, “group”, “supergroup” or “channel” */
	public string $type;

	/** @var string|null Optional. Title, for channels and group chats */
	public ?string $title = null;

	/** @var string|null Optional. Username, for private chats, supergroups and channels if available */
	public ?string $username = null;

	/** @var string|null Optional. First name of the other party in a private chat */
	public ?string $firstName = null;

	/** @var string|null Optional. Last name of the other party in a private chat */
	public ?string $lastName = null;
}
