<?php

namespace TelegramApi\Types;

class InlineQueryResultCachedDocument extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be document */
	public string $type = 'document';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string Title for the result */
	public string $title;

	/** @var string A valid file identifier for the file */
	public string $documentFileId;

	/** @var string|null Optional. Short description of the result */
	public ?string $description = null;

	/** @var string|null Optional. Caption of the document to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var InlineKeyboardMarkup|null Optional. An Inline keyboard attached to the message */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null Optional. Content of the message to be sent instead of the file */
	public ?InputMessageContent $inputMessageContent = null;
}
