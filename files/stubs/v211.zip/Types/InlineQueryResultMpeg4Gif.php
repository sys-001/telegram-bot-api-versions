<?php

namespace TelegramApi\Types;

class InlineQueryResultMpeg4Gif implements TypeInterface
{
	/** @var string */
	public string $type;

	/** @var string */
	public string $id;

	/** @var string */
	public string $mpeg4Url;

	/** @var int|null */
	public ?int $mpeg4Width = null;

	/** @var int|null */
	public ?int $mpeg4Height = null;

	/** @var string */
	public string $thumbUrl;

	/** @var string|null */
	public ?string $title = null;

	/** @var string|null */
	public ?string $caption = null;

	/** @var InlineKeyboardMarkup|null */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null */
	public ?InputMessageContent $inputMessageContent = null;
}
