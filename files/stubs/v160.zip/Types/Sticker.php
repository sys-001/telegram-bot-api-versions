<?php

namespace TelegramApi\Types;

class Sticker implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var int */
	public int $width;

	/** @var int */
	public int $height;

	/** @var PhotoSize|null */
	public ?PhotoSize $thumb = null;

	/** @var int|null */
	public ?int $fileSize = null;
}
