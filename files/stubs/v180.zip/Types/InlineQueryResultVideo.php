<?php

namespace TelegramApi\Types;

class InlineQueryResultVideo implements TypeInterface
{
	/** @var string */
	public string $type;

	/** @var string */
	public string $id;

	/** @var string */
	public string $videoUrl;

	/** @var string */
	public string $mimeType;

	/** @var string */
	public string $messageText;

	/** @var string|null */
	public ?string $parseMode = null;

	/** @var bool|null */
	public ?bool $disableWebPagePreview = null;

	/** @var int|null */
	public ?int $videoWidth = null;

	/** @var int|null */
	public ?int $videoHeight = null;

	/** @var int|null */
	public ?int $videoDuration = null;

	/** @var string */
	public string $thumbUrl;

	/** @var string */
	public string $title;

	/** @var string|null */
	public ?string $description = null;
}
