<?php

namespace TelegramApi\Types;

class Chat implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique identifier for this chat, not exceeding 1e13 by absolute value */
	public int $id;

	/** @var string Type of chat, can be either “private”, “group”, “supergroup” or “channel” */
	public string $type;

	/** @var string|null Optional. Title, for channels and group chats */
	public ?string $title = null;

	/** @var string|null Optional. Username, for private chats and channels if available */
	public ?string $username = null;

	/** @var string|null Optional. First name of the other party in a private chat */
	public ?string $firstName = null;

	/** @var string|null Optional. Last name of the other party in a private chat */
	public ?string $lastName = null;
}
