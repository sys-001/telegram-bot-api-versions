<?php

/**
 * @noinspection PhpUnused
 * @noinspection PhpUnusedParameterInspection
 */

namespace TelegramApi;

use TelegramApi\Types\Chat;
use TelegramApi\Types\File;
use TelegramApi\Types\InlineKeyboardMarkup;
use TelegramApi\Types\Message;
use TelegramApi\Types\User;
use TelegramApi\Types\UserProfilePhotos;

trait API
{
	abstract public function sendRequest(string $method, array $args): mixed;


	public function getMe(): User
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getUserProfilePhotos(int $userId, ?int $offset = null, ?int $limit = null): UserProfilePhotos
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getFile(string $fileId): File
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChat(int|string $chatId): Chat
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChatAdministrators(int|string $chatId): array
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getChatMembersCount(int|string $chatId): int
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerCallbackQuery(
		string $callbackQueryId,
		?string $text = null,
		?bool $showAlert = null,
		?string $url = null,
		?int $cacheTime = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageCaption(
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?string $caption = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function editMessageReplyMarkup(
		int|string|null $chatId = null,
		?int $messageId = null,
		?string $inlineMessageId = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message|bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerShippingQuery(
		string $shippingQueryId,
		bool $ok,
		?array $shippingOptions = null,
		?string $errorMessage = null
	): bool {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function answerPreCheckoutQuery(string $preCheckoutQueryId, bool $ok, ?string $errorMessage = null): bool
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function sendGame(
		int $chatId,
		string $gameShortName,
		?bool $disableNotification = null,
		?int $replyToMessageId = null,
		?InlineKeyboardMarkup $replyMarkup = null
	): Message {
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}
}
