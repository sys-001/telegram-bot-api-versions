<?php

namespace TelegramApi\Types;

class File implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var int|null */
	public ?int $fileSize = null;

	/** @var string|null */
	public ?string $filePath = null;
}
