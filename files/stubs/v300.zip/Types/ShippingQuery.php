<?php

namespace TelegramApi\Types;

class ShippingQuery implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique query identifier */
	public string $id;

	/** @var User User who sent the query */
	public User $from;

	/** @var string Bot specified invoice payload */
	public string $invoicePayload;

	/** @var ShippingAddress User specified shipping address */
	public ShippingAddress $shippingAddress;
}
