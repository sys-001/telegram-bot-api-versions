<?php

namespace TelegramApi\Types;

class ShippingOption implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Shipping option identifier */
	public string $id;

	/** @var string Option title */
	public string $title;

	/** @var Array<LabeledPrice> List of price portions */
	public array $prices;
}
