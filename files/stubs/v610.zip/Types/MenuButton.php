<?php

namespace TelegramApi\Types;

abstract class MenuButton implements TypeInterface
{
}
