<?php

namespace TelegramApi\Types;

class Contact implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Contact's phone number */
	public string $phoneNumber;

	/** @var string Contact's first name */
	public string $firstName;

	/** @var string|null Optional. Contact's last name */
	public ?string $lastName = null;

	/** @var int|null Optional. Contact's user identifier in Telegram */
	public ?int $userId = null;

	/** @var string|null Optional. Additional data about the contact in the form of a vCard */
	public ?string $vcard = null;
}
