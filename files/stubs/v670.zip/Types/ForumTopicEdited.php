<?php

namespace TelegramApi\Types;

class ForumTopicEdited implements TypeInterface
{
	/** @var string|null Optional. New name of the topic, if it was edited */
	public ?string $name = null;

	/** @var string|null Optional. New identifier of the custom emoji shown as the topic icon, if it was edited; an empty string if the icon was removed */
	public ?string $iconCustomEmojiId = null;
}
