<?php

namespace TelegramApi\Types;

class ForumTopicClosed implements TypeInterface
{
}
