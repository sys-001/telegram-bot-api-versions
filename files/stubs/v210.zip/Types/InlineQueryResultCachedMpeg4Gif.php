<?php

namespace TelegramApi\Types;

class InlineQueryResultCachedMpeg4Gif extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be mpeg4_gif */
	public string $type = 'mpeg4_gif';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid file identifier for the MP4 file */
	public string $mpeg4FileId;

	/** @var string|null Optional. Title for the result */
	public ?string $title = null;

	/** @var string|null Optional. Caption of the MPEG-4 file to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var InlineKeyboardMarkup|null Optional. An Inline keyboard attached to the message */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null Optional. Content of the message to be sent instead of the video animation */
	public ?InputMessageContent $inputMessageContent = null;
}
