<?php

namespace TelegramApi\Types;

class ChatMember implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var User Information about the user */
	public User $user;

	/** @var string The member's status in the chat. Can be “creator”, “administrator”, “member”, “left” or “kicked” */
	public string $status;
}
