<?php

namespace TelegramApi\Types;

class Update implements TypeInterface
{
	/** @var int */
	public int $updateId;

	/** @var Message|null */
	public ?Message $message = null;

	/** @var InlineQuery|null */
	public ?InlineQuery $inlineQuery = null;

	/** @var ChosenInlineResult|null */
	public ?ChosenInlineResult $chosenInlineResult = null;
}
