<?php

namespace TelegramApi\Types;

class ChosenInlineResult implements TypeInterface
{
	/** @var string */
	public string $resultId;

	/** @var User */
	public User $from;

	/** @var string */
	public string $query;
}
