<?php

namespace TelegramApi\Types;

class InlineQueryResultArticle implements TypeInterface
{
	/** @var string */
	public string $type;

	/** @var string */
	public string $id;

	/** @var string */
	public string $title;

	/** @var string */
	public string $messageText;

	/** @var string|null */
	public ?string $parseMode = null;

	/** @var bool|null */
	public ?bool $disableWebPagePreview = null;

	/** @var string|null */
	public ?string $url = null;

	/** @var bool|null */
	public ?bool $hideUrl = null;

	/** @var string|null */
	public ?string $description = null;

	/** @var string|null */
	public ?string $thumbUrl = null;

	/** @var int|null */
	public ?int $thumbWidth = null;

	/** @var int|null */
	public ?int $thumbHeight = null;
}
