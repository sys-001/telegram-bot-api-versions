<?php

namespace TelegramApi\Types;

class InlineQueryResultMpeg4Gif extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be mpeg4_gif */
	public string $type = 'mpeg4_gif';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid URL for the MP4 file. File size must not exceed 1MB */
	public string $mpeg4Url;

	/** @var int|null Optional. Video width */
	public ?int $mpeg4Width = null;

	/** @var int|null Optional. Video height */
	public ?int $mpeg4Height = null;

	/** @var string URL of the static thumbnail (jpeg or gif) for the result */
	public string $thumbUrl;

	/** @var string|null Optional. Title for the result */
	public ?string $title = null;

	/** @var string|null Optional. Caption of the MPEG-4 file to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var string|null Optional. Text of a message to be sent instead of the animation, 1-4096 characters */
	public ?string $messageText = null;

	/** @var string|null Optional. Send Markdown or HTML, if you want Telegram apps to show bold, italic, fixed-width text or inline URLs in your bot's message. */
	public ?string $parseMode = null;

	/** @var bool|null Optional. Disables link previews for links in the sent message */
	public ?bool $disableWebPagePreview = null;
}
