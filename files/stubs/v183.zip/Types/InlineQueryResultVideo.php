<?php

namespace TelegramApi\Types;

class InlineQueryResultVideo extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be video */
	public string $type = 'video';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid URL for the embedded video player or video file */
	public string $videoUrl;

	/** @var string Mime type of the content of video url, “text/html” or “video/mp4” */
	public string $mimeType;

	/** @var string Text of the message to be sent with the video, 1-4096 characters */
	public string $messageText;

	/** @var string|null Optional. Send Markdown or HTML, if you want Telegram apps to show bold, italic, fixed-width text or inline URLs in your bot's message. */
	public ?string $parseMode = null;

	/** @var bool|null Optional. Disables link previews for links in the sent message */
	public ?bool $disableWebPagePreview = null;

	/** @var int|null Optional. Video width */
	public ?int $videoWidth = null;

	/** @var int|null Optional. Video height */
	public ?int $videoHeight = null;

	/** @var int|null Optional. Video duration in seconds */
	public ?int $videoDuration = null;

	/** @var string URL of the thumbnail (jpeg only) for the video */
	public string $thumbUrl;

	/** @var string Title for the result */
	public string $title;

	/** @var string|null Optional. Short description of the result */
	public ?string $description = null;
}
