<?php

namespace TelegramApi\Types;

class InlineQueryResultPhoto implements TypeInterface
{
	/** @var string */
	public string $type;

	/** @var string */
	public string $id;

	/** @var string */
	public string $photoUrl;

	/** @var int|null */
	public ?int $photoWidth = null;

	/** @var int|null */
	public ?int $photoHeight = null;

	/** @var string */
	public string $thumbUrl;

	/** @var string|null */
	public ?string $title = null;

	/** @var string|null */
	public ?string $description = null;

	/** @var string|null */
	public ?string $caption = null;

	/** @var string|null */
	public ?string $messageText = null;

	/** @var string|null */
	public ?string $parseMode = null;

	/** @var bool|null */
	public ?bool $disableWebPagePreview = null;
}
