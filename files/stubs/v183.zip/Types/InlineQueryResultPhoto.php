<?php

namespace TelegramApi\Types;

class InlineQueryResultPhoto extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be photo */
	public string $type = 'photo';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid URL of the photo. Photo must be in jpeg format. Photo size must not exceed 5MB */
	public string $photoUrl;

	/** @var int|null Optional. Width of the photo */
	public ?int $photoWidth = null;

	/** @var int|null Optional. Height of the photo */
	public ?int $photoHeight = null;

	/** @var string URL of the thumbnail for the photo */
	public string $thumbUrl;

	/** @var string|null Optional. Title for the result */
	public ?string $title = null;

	/** @var string|null Optional. Short description of the result */
	public ?string $description = null;

	/** @var string|null Optional. Caption of the photo to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var string|null Optional. Text of a message to be sent instead of the photo, 1-4096 characters */
	public ?string $messageText = null;

	/** @var string|null Optional. Send Markdown or HTML, if you want Telegram apps to show bold, italic, fixed-width text or inline URLs in your bot's message. */
	public ?string $parseMode = null;

	/** @var bool|null Optional. Disables link previews for links in the sent message */
	public ?bool $disableWebPagePreview = null;
}
