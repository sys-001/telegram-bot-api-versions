<?php

namespace TelegramApi\Types;

class User implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique identifier for this user or bot */
	public int $id;

	/** @var string User‘s or bot’s first name */
	public string $firstName;

	/** @var string|null Optional. User‘s or bot’s last name */
	public ?string $lastName = null;

	/** @var string|null Optional. User‘s or bot’s username */
	public ?string $username = null;
}
