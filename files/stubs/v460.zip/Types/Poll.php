<?php

namespace TelegramApi\Types;

class Poll implements TypeInterface
{
	/** @var string Unique poll identifier */
	public string $id;

	/** @var string Poll question, 1-255 characters */
	public string $question;

	/** @var Array<PollOption> List of poll options */
	public array $options;

	/** @var int Total number of users that voted in the poll */
	public int $totalVoterCount;

	/** @var bool True, if the poll is closed */
	public bool $isClosed;

	/** @var bool True, if the poll is anonymous */
	public bool $isAnonymous;

	/** @var string Poll type, currently can be “regular” or “quiz” */
	public string $type;

	/** @var bool True, if the poll allows multiple answers */
	public bool $allowsMultipleAnswers;

	/** @var int|null Optional. 0-based identifier of the correct answer option. Available only for polls in the quiz mode, which are closed, or was sent (not forwarded) by the bot or to the private chat with the bot. */
	public ?int $correctOptionId = null;
}
