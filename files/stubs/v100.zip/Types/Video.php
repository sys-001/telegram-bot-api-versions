<?php

namespace TelegramApi\Types;

class Video implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Video width as defined by sender */
	public int $width;

	/** @var int Video height as defined by sender */
	public int $height;

	/** @var int Duration of the video in seconds as defined by sender */
	public int $duration;

	/** @var PhotoSize Video thumbnail */
	public PhotoSize $thumb;

	/** @var string|null Optional. Mime type of a file as defined by sender */
	public ?string $mimeType = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;

	/** @var string|null Optional. Text description of the video (usually empty) */
	public ?string $caption = null;
}
