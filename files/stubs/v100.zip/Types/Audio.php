<?php

namespace TelegramApi\Types;

class Audio implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Duration of the audio in seconds as defined by sender */
	public int $duration;

	/** @var string|null Optional. MIME type of the file as defined by sender */
	public ?string $mimeType = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
