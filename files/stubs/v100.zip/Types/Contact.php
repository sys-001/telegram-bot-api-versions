<?php

namespace TelegramApi\Types;

class Contact implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Contact's phone number */
	public string $phoneNumber;

	/** @var string Contact's first name */
	public string $firstName;

	/** @var string|null Optional. Contact's last name */
	public ?string $lastName = null;

	/** @var string|null Optional. Contact's user identifier in Telegram */
	public ?string $userId = null;
}
