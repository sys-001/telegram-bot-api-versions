<?php

namespace TelegramApi\Types;

class Contact implements TypeInterface
{
	/** @var string */
	public string $phoneNumber;

	/** @var string */
	public string $firstName;

	/** @var string|null */
	public ?string $lastName = null;

	/** @var string|null */
	public ?string $userId = null;
}
