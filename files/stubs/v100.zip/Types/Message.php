<?php

namespace TelegramApi\Types;

class Message implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique message identifier */
	public int $messageId;

	/** @var User Sender */
	public User $from;

	/** @var int Date the message was sent in Unix time */
	public int $date;

	/** @var User|GroupChat Conversation the message belongs to — user in case of a private message, GroupChat in case of a group */
	public User|GroupChat $chat;

	/** @var User|null Optional. For forwarded messages, sender of the original message */
	public ?User $forwardFrom = null;

	/** @var int|null Optional. For forwarded messages, date the original message was sent in Unix time */
	public ?int $forwardDate = null;

	/** @var Message|null Optional. For replies, the original message. Note that the Message object in this field will not contain further reply_to_message fields even if it itself is a reply. */
	public ?Message $replyToMessage = null;

	/** @var string|null Optional. For text messages, the actual UTF-8 text of the message */
	public ?string $text = null;

	/** @var Audio|null Optional. Message is an audio file, information about the file */
	public ?Audio $audio = null;

	/** @var Document|null Optional. Message is a general file, information about the file */
	public ?Document $document = null;

	/** @var Array<PhotoSize>|null Optional. Message is a photo, available sizes of the photo */
	public ?array $photo = null;

	/** @var Sticker|null Optional. Message is a sticker, information about the sticker */
	public ?Sticker $sticker = null;

	/** @var Video|null Optional. Message is a video, information about the video */
	public ?Video $video = null;

	/** @var Contact|null Optional. Message is a shared contact, information about the contact */
	public ?Contact $contact = null;

	/** @var Location|null Optional. Message is a shared location, information about the location */
	public ?Location $location = null;

	/** @var User|null Optional. A new member was added to the group, information about them (this member may be bot itself) */
	public ?User $newChatParticipant = null;

	/** @var User|null Optional. A member was removed from the group, information about them (this member may be bot itself) */
	public ?User $leftChatParticipant = null;

	/** @var string|null Optional. A group title was changed to this value */
	public ?string $newChatTitle = null;

	/** @var Array<PhotoSize>|null Optional. A group photo was change to this value */
	public ?array $newChatPhoto = null;

	/** @var bool|null Optional. Informs that the group photo was deleted */
	public ?bool $deleteChatPhoto = true;

	/** @var bool|null Optional. Informs that the group has been created */
	public ?bool $groupChatCreated = true;
}
