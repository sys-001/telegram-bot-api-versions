<?php

namespace TelegramApi\Types;

class Document implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique file identifier */
	public string $fileId;

	/** @var PhotoSize Document thumbnail as defined by sender */
	public PhotoSize $thumb;

	/** @var string|null Optional. Original filename as defined by sender */
	public ?string $fileName = null;

	/** @var string|null Optional. MIME type of the file as defined by sender */
	public ?string $mimeType = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
