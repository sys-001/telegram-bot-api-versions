<?php

namespace TelegramApi\Types;

class Document implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var PhotoSize */
	public PhotoSize $thumb;

	/** @var string|null */
	public ?string $fileName = null;

	/** @var string|null */
	public ?string $mimeType = null;

	/** @var int|null */
	public ?int $fileSize = null;
}
