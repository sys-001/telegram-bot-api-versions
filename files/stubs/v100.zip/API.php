<?php

/**
 * @noinspection PhpUnused
 * @noinspection PhpUnusedParameterInspection
 */

namespace TelegramApi;

use TelegramApi\Types\User;
use TelegramApi\Types\UserProfilePhotos;

trait API
{
	abstract public function sendRequest(string $method, array $args): mixed;


	public function getMe(): User
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}


	public function getUserProfilePhotos(int $userId, ?int $offset = null, ?int $limit = null): UserProfilePhotos
	{
		$args = get_defined_vars();
		return $this->sendRequest(__FUNCTION__, $args);
	}
}
