<?php

namespace TelegramApi\Types;

class InlineQueryResultCachedGif extends InlineQueryResult
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be gif */
	public string $type = 'gif';

	/** @var string Unique identifier for this result, 1-64 bytes */
	public string $id;

	/** @var string A valid file identifier for the GIF file */
	public string $gifFileId;

	/** @var string|null Optional. Title for the result */
	public ?string $title = null;

	/** @var string|null Optional. Caption of the GIF file to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var InlineKeyboardMarkup|null Optional. Inline keyboard attached to the message */
	public ?InlineKeyboardMarkup $replyMarkup = null;

	/** @var InputMessageContent|null Optional. Content of the message to be sent instead of the GIF animation */
	public ?InputMessageContent $inputMessageContent = null;
}
