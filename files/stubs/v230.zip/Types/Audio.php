<?php

namespace TelegramApi\Types;

class Audio implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var int */
	public int $duration;

	/** @var string|null */
	public ?string $performer = null;

	/** @var string|null */
	public ?string $title = null;

	/** @var string|null */
	public ?string $mimeType = null;

	/** @var int|null */
	public ?int $fileSize = null;
}
