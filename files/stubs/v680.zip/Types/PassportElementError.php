<?php

namespace TelegramApi\Types;

abstract class PassportElementError implements TypeInterface
{
}
