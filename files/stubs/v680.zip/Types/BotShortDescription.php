<?php

namespace TelegramApi\Types;

class BotShortDescription implements TypeInterface
{
	/** @var string The bot's short description */
	public string $shortDescription;
}
