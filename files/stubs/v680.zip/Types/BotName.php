<?php

namespace TelegramApi\Types;

class BotName implements TypeInterface
{
	/** @var string The bot's name */
	public string $name;
}
