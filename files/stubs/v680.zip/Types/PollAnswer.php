<?php

namespace TelegramApi\Types;

class PollAnswer implements TypeInterface
{
	/** @var string Unique poll identifier */
	public string $pollId;

	/** @var Chat|null Optional. The chat that changed the answer to the poll, if the voter is anonymous */
	public ?Chat $voterChat = null;

	/** @var User|null Optional. The user that changed the answer to the poll, if the voter isn't anonymous */
	public ?User $user = null;

	/** @var Array<int> 0-based identifiers of chosen answer options. May be empty if the vote was retracted. */
	public array $optionIds;
}
