<?php

namespace TelegramApi\Types;

class WriteAccessAllowed implements TypeInterface
{
	/** @var string|null Optional. Name of the Web App which was launched from a link */
	public ?string $webAppName = null;
}
