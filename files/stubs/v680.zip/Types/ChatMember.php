<?php

namespace TelegramApi\Types;

abstract class ChatMember implements TypeInterface
{
}
