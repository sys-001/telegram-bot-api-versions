<?php

namespace TelegramApi\Types;

class PassportFile implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int File size */
	public int $fileSize;

	/** @var int Unix time when the file was uploaded */
	public int $fileDate;
}
