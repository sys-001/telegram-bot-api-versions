<?php

namespace TelegramApi\Types;

class StickerSet implements TypeInterface
{
	/** @var string Sticker set name */
	public string $name;

	/** @var string Sticker set title */
	public string $title;

	/** @var bool True, if the sticker set contains animated stickers */
	public bool $isAnimated;

	/** @var bool True, if the sticker set contains masks */
	public bool $containsMasks;

	/** @var Array<Sticker> List of all set stickers */
	public array $stickers;
}
