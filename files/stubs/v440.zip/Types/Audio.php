<?php

namespace TelegramApi\Types;

class Audio implements TypeInterface
{
	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Duration of the audio in seconds as defined by sender */
	public int $duration;

	/** @var string|null Optional. Performer of the audio as defined by sender or by audio tags */
	public ?string $performer = null;

	/** @var string|null Optional. Title of the audio as defined by sender or by audio tags */
	public ?string $title = null;

	/** @var string|null Optional. MIME type of the file as defined by sender */
	public ?string $mimeType = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;

	/** @var PhotoSize|null Optional. Thumbnail of the album cover to which the music file belongs */
	public ?PhotoSize $thumb = null;
}
