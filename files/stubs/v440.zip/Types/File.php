<?php

namespace TelegramApi\Types;

class File implements TypeInterface
{
	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int|null Optional. File size, if known */
	public ?int $fileSize = null;

	/** @var string|null Optional. File path. Use https://api.telegram.org/file/bot<token>/<file_path> to get the file. */
	public ?string $filePath = null;
}
