<?php

namespace TelegramApi\Types;

class PassportFile implements TypeInterface
{
	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int File size */
	public int $fileSize;

	/** @var int Unix time when the file was uploaded */
	public int $fileDate;
}
