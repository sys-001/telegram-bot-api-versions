<?php

namespace TelegramApi\Types;

class Chat implements TypeInterface
{
	/** @var int Unique identifier for this chat. This number may be greater than 32 bits and some programming languages may have difficulty/silent defects in interpreting it. But it is smaller than 52 bits, so a signed 64 bit integer or double-precision float type are safe for storing this identifier. */
	public int $id;

	/** @var string Type of chat, can be either “private”, “group”, “supergroup” or “channel” */
	public string $type;

	/** @var string|null Optional. Title, for supergroups, channels and group chats */
	public ?string $title = null;

	/** @var string|null Optional. Username, for private chats, supergroups and channels if available */
	public ?string $username = null;

	/** @var string|null Optional. First name of the other party in a private chat */
	public ?string $firstName = null;

	/** @var string|null Optional. Last name of the other party in a private chat */
	public ?string $lastName = null;

	/** @var ChatPhoto|null Optional. Chat photo. Returned only in getChat. */
	public ?ChatPhoto $photo = null;

	/** @var string|null Optional. Description, for groups, supergroups and channel chats. Returned only in getChat. */
	public ?string $description = null;

	/** @var string|null Optional. Chat invite link, for groups, supergroups and channel chats. Each administrator in a chat generates their own invite links, so the bot must first generate the link using exportChatInviteLink. Returned only in getChat. */
	public ?string $inviteLink = null;

	/** @var Message|null Optional. Pinned message, for groups, supergroups and channels. Returned only in getChat. */
	public ?Message $pinnedMessage = null;

	/** @var ChatPermissions|null Optional. Default chat member permissions, for groups and supergroups. Returned only in getChat. */
	public ?ChatPermissions $permissions = null;

	/** @var string|null Optional. For supergroups, name of group sticker set. Returned only in getChat. */
	public ?string $stickerSetName = null;

	/** @var bool|null Optional. True, if the bot can change the group sticker set. Returned only in getChat. */
	public ?bool $canSetStickerSet = null;
}
