<?php

namespace TelegramApi\Types;

class Sticker implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var int */
	public int $width;

	/** @var int */
	public int $height;

	/** @var bool */
	public bool $isAnimated;

	/** @var PhotoSize|null */
	public ?PhotoSize $thumb = null;

	/** @var string|null */
	public ?string $emoji = null;

	/** @var string|null */
	public ?string $setName = null;

	/** @var MaskPosition|null */
	public ?MaskPosition $maskPosition = null;

	/** @var int|null */
	public ?int $fileSize = null;
}
