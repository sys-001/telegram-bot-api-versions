<?php

namespace TelegramApi\Types;

class GroupChat implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique identifier for this group chat */
	public int $id;

	/** @var string Group name */
	public string $title;
}
