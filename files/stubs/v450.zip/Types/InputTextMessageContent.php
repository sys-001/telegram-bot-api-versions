<?php

namespace TelegramApi\Types;

class InputTextMessageContent extends InputMessageContent
{
	/** @var string */
	public string $messageText;

	/** @var string|null */
	public ?string $parseMode = null;

	/** @var bool|null */
	public ?bool $disableWebPagePreview = null;
}
