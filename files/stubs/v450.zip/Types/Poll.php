<?php

namespace TelegramApi\Types;

class Poll implements TypeInterface
{
	/** @var string */
	public string $id;

	/** @var string */
	public string $question;

	/** @var Array<PollOption> */
	public array $options;

	/** @var bool */
	public bool $isClosed;
}
