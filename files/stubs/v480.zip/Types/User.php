<?php

namespace TelegramApi\Types;

class User implements TypeInterface
{
	/** @var int */
	public int $id;

	/** @var bool */
	public bool $isBot;

	/** @var string */
	public string $firstName;

	/** @var string|null */
	public ?string $lastName = null;

	/** @var string|null */
	public ?string $username = null;

	/** @var string|null */
	public ?string $languageCode = null;

	/** @var bool|null */
	public ?bool $canJoinGroups = null;

	/** @var bool|null */
	public ?bool $canReadAllGroupMessages = null;

	/** @var bool|null */
	public ?bool $supportsInlineQueries = null;
}
