<?php

namespace TelegramApi\Types;

class KeyboardButtonPollType implements TypeInterface
{
	/** @var string|null */
	public ?string $type = null;
}
