<?php

namespace TelegramApi\Types;

class ChatLocation implements TypeInterface
{
	/** @var Location */
	public Location $location;

	/** @var string */
	public string $address;
}
