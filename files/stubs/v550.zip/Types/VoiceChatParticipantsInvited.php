<?php

namespace TelegramApi\Types;

class VoiceChatParticipantsInvited implements TypeInterface
{
	/** @var Array<User>|null */
	public ?array $users = null;
}
