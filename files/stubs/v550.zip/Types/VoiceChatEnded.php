<?php

namespace TelegramApi\Types;

class VoiceChatEnded implements TypeInterface
{
	/** @var int */
	public int $duration;
}
