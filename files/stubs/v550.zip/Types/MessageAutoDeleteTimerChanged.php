<?php

namespace TelegramApi\Types;

class MessageAutoDeleteTimerChanged implements TypeInterface
{
	/** @var int */
	public int $messageAutoDeleteTime;
}
