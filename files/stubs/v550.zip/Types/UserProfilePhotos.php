<?php

namespace TelegramApi\Types;

class UserProfilePhotos implements TypeInterface
{
	/** @var int */
	public int $totalCount;

	/** @var Array<Array<PhotoSize>> */
	public array $photos;
}
