<?php

namespace TelegramApi\Types;

class ChatJoinRequest implements TypeInterface
{
	/** @var Chat */
	public Chat $chat;

	/** @var User */
	public User $from;

	/** @var int */
	public int $date;

	/** @var string|null */
	public ?string $bio = null;

	/** @var ChatInviteLink|null */
	public ?ChatInviteLink $inviteLink = null;
}
