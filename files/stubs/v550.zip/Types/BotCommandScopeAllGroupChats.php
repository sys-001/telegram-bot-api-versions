<?php

namespace TelegramApi\Types;

class BotCommandScopeAllGroupChats extends BotCommandScope
{
	/** @var string */
	public string $type;
}
