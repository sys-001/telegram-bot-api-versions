<?php

namespace TelegramApi\Types;

class InputTextMessageContent extends InputMessageContent
{
	/** @var Type Description */
	public Type $field;

	/** @var string Text of the message to be sent, 1-4096 characters */
	public string $messageText;

	/** @var string|null Optional. Send Markdown or HTML, if you want Telegram apps to show bold, italic, fixed-width text or inline URLs in your bot's message. */
	public ?string $parseMode = null;

	/** @var bool|null Optional. Disables link previews for links in the sent message */
	public ?bool $disableWebPagePreview = null;
}
