<?php

namespace TelegramApi\Types;

class Location implements TypeInterface
{
	/** @var float Longitude as defined by sender */
	public float $longitude;

	/** @var float Latitude as defined by sender */
	public float $latitude;
}
