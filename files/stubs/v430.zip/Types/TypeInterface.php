<?php

namespace TelegramApi\Types;

interface TypeInterface
{
}
