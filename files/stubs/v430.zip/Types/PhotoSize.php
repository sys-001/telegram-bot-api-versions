<?php

namespace TelegramApi\Types;

class PhotoSize implements TypeInterface
{
	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Photo width */
	public int $width;

	/** @var int Photo height */
	public int $height;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
