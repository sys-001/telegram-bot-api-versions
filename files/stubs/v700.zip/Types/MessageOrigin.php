<?php

namespace TelegramApi\Types;

abstract class MessageOrigin implements TypeInterface
{
}
