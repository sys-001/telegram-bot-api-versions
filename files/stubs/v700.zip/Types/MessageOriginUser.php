<?php

namespace TelegramApi\Types;

class MessageOriginUser extends MessageOrigin
{
	/** @var string Type of the message origin, always “user” */
	public string $type;

	/** @var int Date the message was sent originally in Unix time */
	public int $date;

	/** @var User User that sent the message originally */
	public User $senderUser;
}
