<?php

namespace TelegramApi\Types;

class ChatBoostRemoved implements TypeInterface
{
	/** @var Chat Chat which was boosted */
	public Chat $chat;

	/** @var string Unique identifier of the boost */
	public string $boostId;

	/** @var int Point in time (Unix timestamp) when the boost was removed */
	public int $removeDate;

	/** @var ChatBoostSource Source of the removed boost */
	public ChatBoostSource $source;
}
