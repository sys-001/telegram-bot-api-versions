<?php

namespace TelegramApi\Types;

class UserChatBoosts implements TypeInterface
{
	/** @var Array<ChatBoost> The list of boosts added to the chat by the user */
	public array $boosts;
}
