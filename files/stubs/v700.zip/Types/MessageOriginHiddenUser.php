<?php

namespace TelegramApi\Types;

class MessageOriginHiddenUser extends MessageOrigin
{
	/** @var string Type of the message origin, always “hidden_user” */
	public string $type;

	/** @var int Date the message was sent originally in Unix time */
	public int $date;

	/** @var string Name of the user that sent the message originally */
	public string $senderUserName;
}
