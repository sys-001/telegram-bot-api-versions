<?php

namespace TelegramApi\Types;

abstract class ReactionType implements TypeInterface
{
}
