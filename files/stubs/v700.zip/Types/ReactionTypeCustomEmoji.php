<?php

namespace TelegramApi\Types;

class ReactionTypeCustomEmoji extends ReactionType
{
	/** @var string Type of the reaction, always “custom_emoji” */
	public string $type;

	/** @var string Custom emoji identifier */
	public string $customEmojiId;
}
