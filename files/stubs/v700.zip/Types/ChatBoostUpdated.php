<?php

namespace TelegramApi\Types;

class ChatBoostUpdated implements TypeInterface
{
	/** @var Chat Chat which was boosted */
	public Chat $chat;

	/** @var ChatBoost Infomation about the chat boost */
	public ChatBoost $boost;
}
