<?php

namespace TelegramApi\Types;

class MessageOriginChannel extends MessageOrigin
{
	/** @var string Type of the message origin, always “channel” */
	public string $type;

	/** @var int Date the message was sent originally in Unix time */
	public int $date;

	/** @var Chat Channel chat to which the message was originally sent */
	public Chat $chat;

	/** @var int Unique message identifier inside the chat */
	public int $messageId;

	/** @var string|null Optional. Signature of the original post author */
	public ?string $authorSignature = null;
}
