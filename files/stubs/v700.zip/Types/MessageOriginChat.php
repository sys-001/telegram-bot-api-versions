<?php

namespace TelegramApi\Types;

class MessageOriginChat extends MessageOrigin
{
	/** @var string Type of the message origin, always “chat” */
	public string $type;

	/** @var int Date the message was sent originally in Unix time */
	public int $date;

	/** @var Chat Chat that sent the message originally */
	public Chat $senderChat;

	/** @var string|null Optional. For messages originally sent by an anonymous chat administrator, original message author signature */
	public ?string $authorSignature = null;
}
