<?php

namespace TelegramApi\Types;

class GiveawayCompleted implements TypeInterface
{
	/** @var int Number of winners in the giveaway */
	public int $winnerCount;

	/** @var int|null Optional. Number of undistributed prizes */
	public ?int $unclaimedPrizeCount = null;

	/** @var Message|null Optional. Message with the giveaway that was completed, if it wasn't deleted */
	public ?Message $giveawayMessage = null;
}
