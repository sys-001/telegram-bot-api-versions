<?php

namespace TelegramApi\Types;

class MessageReactionUpdated implements TypeInterface
{
	/** @var Chat The chat containing the message the user reacted to */
	public Chat $chat;

	/** @var int Unique identifier of the message inside the chat */
	public int $messageId;

	/** @var User|null Optional. The user that changed the reaction, if the user isn't anonymous */
	public ?User $user = null;

	/** @var Chat|null Optional. The chat on behalf of which the reaction was changed, if the user is anonymous */
	public ?Chat $actorChat = null;

	/** @var int Date of the change in Unix time */
	public int $date;

	/** @var Array<ReactionType> Previous list of reaction types that were set by the user */
	public array $oldReaction;

	/** @var Array<ReactionType> New list of reaction types that have been set by the user */
	public array $newReaction;
}
