<?php

namespace TelegramApi\Types;

class ChatBoostSourceGiveaway extends ChatBoostSource
{
	/** @var string Source of the boost, always “giveaway” */
	public string $source;

	/** @var int Identifier of a message in the chat with the giveaway; the message could have been deleted already. May be 0 if the message isn't sent yet. */
	public int $giveawayMessageId;

	/** @var User|null Optional. User that won the prize in the giveaway if any */
	public ?User $user = null;

	/** @var bool|null Optional. True, if the giveaway was completed, but there was no user to win the prize */
	public ?bool $isUnclaimed = true;
}
