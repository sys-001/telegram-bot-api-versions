<?php

namespace TelegramApi\Types;

class BotDescription implements TypeInterface
{
	/** @var string The bot's description */
	public string $description;
}
