<?php

namespace TelegramApi\Types;

class MessageReactionCountUpdated implements TypeInterface
{
	/** @var Chat The chat containing the message */
	public Chat $chat;

	/** @var int Unique message identifier inside the chat */
	public int $messageId;

	/** @var int Date of the change in Unix time */
	public int $date;

	/** @var Array<ReactionCount> List of reactions that are present on the message */
	public array $reactions;
}
