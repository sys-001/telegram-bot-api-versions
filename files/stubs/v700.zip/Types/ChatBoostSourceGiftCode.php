<?php

namespace TelegramApi\Types;

class ChatBoostSourceGiftCode extends ChatBoostSource
{
	/** @var string Source of the boost, always “gift_code” */
	public string $source;

	/** @var User User for which the gift code was created */
	public User $user;
}
