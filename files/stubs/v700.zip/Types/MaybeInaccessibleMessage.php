<?php

namespace TelegramApi\Types;

abstract class MaybeInaccessibleMessage implements TypeInterface
{
}
