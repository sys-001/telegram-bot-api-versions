<?php

namespace TelegramApi\Types;

class ExternalReplyInfo implements TypeInterface
{
	/** @var MessageOrigin Origin of the message replied to by the given message */
	public MessageOrigin $origin;

	/** @var Chat|null Optional. Chat the original message belongs to. Available only if the chat is a supergroup or a channel. */
	public ?Chat $chat = null;

	/** @var int|null Optional. Unique message identifier inside the original chat. Available only if the original chat is a supergroup or a channel. */
	public ?int $messageId = null;

	/** @var LinkPreviewOptions|null Optional. Options used for link preview generation for the original message, if it is a text message */
	public ?LinkPreviewOptions $linkPreviewOptions = null;

	/** @var Animation|null Optional. Message is an animation, information about the animation */
	public ?Animation $animation = null;

	/** @var Audio|null Optional. Message is an audio file, information about the file */
	public ?Audio $audio = null;

	/** @var Document|null Optional. Message is a general file, information about the file */
	public ?Document $document = null;

	/** @var Array<PhotoSize>|null Optional. Message is a photo, available sizes of the photo */
	public ?array $photo = null;

	/** @var Sticker|null Optional. Message is a sticker, information about the sticker */
	public ?Sticker $sticker = null;

	/** @var Story|null Optional. Message is a forwarded story */
	public ?Story $story = null;

	/** @var Video|null Optional. Message is a video, information about the video */
	public ?Video $video = null;

	/** @var VideoNote|null Optional. Message is a video note, information about the video message */
	public ?VideoNote $videoNote = null;

	/** @var Voice|null Optional. Message is a voice message, information about the file */
	public ?Voice $voice = null;

	/** @var bool|null Optional. True, if the message media is covered by a spoiler animation */
	public ?bool $hasMediaSpoiler = true;

	/** @var Contact|null Optional. Message is a shared contact, information about the contact */
	public ?Contact $contact = null;

	/** @var Dice|null Optional. Message is a dice with random value */
	public ?Dice $dice = null;

	/** @var Game|null Optional. Message is a game, information about the game. More about games » */
	public ?Game $game = null;

	/** @var Giveaway|null Optional. Message is a scheduled giveaway, information about the giveaway */
	public ?Giveaway $giveaway = null;

	/** @var GiveawayWinners|null Optional. A giveaway with public winners was completed */
	public ?GiveawayWinners $giveawayWinners = null;

	/** @var Invoice|null Optional. Message is an invoice for a payment, information about the invoice. More about payments » */
	public ?Invoice $invoice = null;

	/** @var Location|null Optional. Message is a shared location, information about the location */
	public ?Location $location = null;

	/** @var Poll|null Optional. Message is a native poll, information about the poll */
	public ?Poll $poll = null;

	/** @var Venue|null Optional. Message is a venue, information about the venue */
	public ?Venue $venue = null;
}
