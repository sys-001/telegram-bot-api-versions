<?php

namespace TelegramApi\Types;

class GiveawayWinners implements TypeInterface
{
	/** @var Chat The chat that created the giveaway */
	public Chat $chat;

	/** @var int Identifier of the messsage with the giveaway in the chat */
	public int $giveawayMessageId;

	/** @var int Point in time (Unix timestamp) when winners of the giveaway were selected */
	public int $winnersSelectionDate;

	/** @var int Total number of winners in the giveaway */
	public int $winnerCount;

	/** @var Array<User> List of up to 100 winners of the giveaway */
	public array $winners;

	/** @var int|null Optional. The number of other chats the user had to join in order to be eligible for the giveaway */
	public ?int $additionalChatCount = null;

	/** @var int|null Optional. The number of months the Telegram Premium subscription won from the giveaway will be active for */
	public ?int $premiumSubscriptionMonthCount = null;

	/** @var int|null Optional. Number of undistributed prizes */
	public ?int $unclaimedPrizeCount = null;

	/** @var bool|null Optional. True, if only users who had joined the chats after the giveaway started were eligible to win */
	public ?bool $onlyNewMembers = true;

	/** @var bool|null Optional. True, if the giveaway was canceled because the payment for it was refunded */
	public ?bool $wasRefunded = true;

	/** @var string|null Optional. Description of additional giveaway prize */
	public ?string $prizeDescription = null;
}
