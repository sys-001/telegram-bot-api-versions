<?php

namespace TelegramApi\Types;

class GiveawayCreated implements TypeInterface
{
}
