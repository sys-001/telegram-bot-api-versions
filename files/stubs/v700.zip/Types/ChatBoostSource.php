<?php

namespace TelegramApi\Types;

abstract class ChatBoostSource implements TypeInterface
{
}
