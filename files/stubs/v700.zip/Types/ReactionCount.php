<?php

namespace TelegramApi\Types;

class ReactionCount implements TypeInterface
{
	/** @var ReactionType Type of the reaction */
	public ReactionType $type;

	/** @var int Number of times the reaction was added */
	public int $totalCount;
}
