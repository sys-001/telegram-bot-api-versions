<?php

namespace TelegramApi\Types;

class ChatBoostSourcePremium extends ChatBoostSource
{
	/** @var string Source of the boost, always “premium” */
	public string $source;

	/** @var User User that boosted the chat */
	public User $user;
}
