<?php

namespace TelegramApi\Types;

class Story implements TypeInterface
{
}
