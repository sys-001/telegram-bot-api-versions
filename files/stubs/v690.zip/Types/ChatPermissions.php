<?php

namespace TelegramApi\Types;

class ChatPermissions implements TypeInterface
{
	/** @var bool|null Optional. True, if the user is allowed to send text messages, contacts, invoices, locations and venues */
	public ?bool $canSendMessages = null;

	/** @var bool|null Optional. True, if the user is allowed to send audios */
	public ?bool $canSendAudios = null;

	/** @var bool|null Optional. True, if the user is allowed to send documents */
	public ?bool $canSendDocuments = null;

	/** @var bool|null Optional. True, if the user is allowed to send photos */
	public ?bool $canSendPhotos = null;

	/** @var bool|null Optional. True, if the user is allowed to send videos */
	public ?bool $canSendVideos = null;

	/** @var bool|null Optional. True, if the user is allowed to send video notes */
	public ?bool $canSendVideoNotes = null;

	/** @var bool|null Optional. True, if the user is allowed to send voice notes */
	public ?bool $canSendVoiceNotes = null;

	/** @var bool|null Optional. True, if the user is allowed to send polls */
	public ?bool $canSendPolls = null;

	/** @var bool|null Optional. True, if the user is allowed to send animations, games, stickers and use inline bots */
	public ?bool $canSendOtherMessages = null;

	/** @var bool|null Optional. True, if the user is allowed to add web page previews to their messages */
	public ?bool $canAddWebPagePreviews = null;

	/** @var bool|null Optional. True, if the user is allowed to change the chat title, photo and other settings. Ignored in public supergroups */
	public ?bool $canChangeInfo = null;

	/** @var bool|null Optional. True, if the user is allowed to invite new users to the chat */
	public ?bool $canInviteUsers = null;

	/** @var bool|null Optional. True, if the user is allowed to pin messages. Ignored in public supergroups */
	public ?bool $canPinMessages = null;

	/** @var bool|null Optional. True, if the user is allowed to create forum topics. If omitted defaults to the value of can_pin_messages */
	public ?bool $canManageTopics = null;
}
