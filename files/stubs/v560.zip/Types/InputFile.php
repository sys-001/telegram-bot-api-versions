<?php

namespace TelegramApi\Types;

class InputFile implements TypeInterface
{
}
