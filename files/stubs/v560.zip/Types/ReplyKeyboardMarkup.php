<?php

namespace TelegramApi\Types;

class ReplyKeyboardMarkup implements TypeInterface
{
	/** @var Array<Array<KeyboardButton>> */
	public array $keyboard;

	/** @var bool|null */
	public ?bool $resizeKeyboard = null;

	/** @var bool|null */
	public ?bool $oneTimeKeyboard = null;

	/** @var string|null */
	public ?string $inputFieldPlaceholder = null;

	/** @var bool|null */
	public ?bool $selective = null;
}
