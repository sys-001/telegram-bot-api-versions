<?php

namespace TelegramApi\Types;

class PassportFile implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var string */
	public string $fileUniqueId;

	/** @var int */
	public int $fileSize;

	/** @var int */
	public int $fileDate;
}
