<?php

namespace TelegramApi\Types;

class InlineKeyboardMarkup implements TypeInterface
{
	/** @var Array<Array<InlineKeyboardButton>> */
	public array $inlineKeyboard;
}
