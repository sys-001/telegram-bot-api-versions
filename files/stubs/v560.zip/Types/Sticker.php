<?php

namespace TelegramApi\Types;

class Sticker implements TypeInterface
{
	/** @var string Identifier for this file, which can be used to download or reuse the file */
	public string $fileId;

	/** @var string Unique identifier for this file, which is supposed to be the same over time and for different bots. Can't be used to download or reuse the file. */
	public string $fileUniqueId;

	/** @var int Sticker width */
	public int $width;

	/** @var int Sticker height */
	public int $height;

	/** @var bool True, if the sticker is animated */
	public bool $isAnimated;

	/** @var PhotoSize|null Optional. Sticker thumbnail in the .WEBP or .JPG format */
	public ?PhotoSize $thumb = null;

	/** @var string|null Optional. Emoji associated with the sticker */
	public ?string $emoji = null;

	/** @var string|null Optional. Name of the sticker set to which the sticker belongs */
	public ?string $setName = null;

	/** @var MaskPosition|null Optional. For mask stickers, the position where the mask should be placed */
	public ?MaskPosition $maskPosition = null;

	/** @var int|null Optional. File size in bytes */
	public ?int $fileSize = null;
}
