<?php

namespace TelegramApi\Types;

class VoiceChatParticipantsInvited implements TypeInterface
{
	/** @var Array<User>|null Optional. New members that were invited to the voice chat */
	public ?array $users = null;
}
