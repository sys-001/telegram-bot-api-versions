<?php

namespace TelegramApi\Types;

class ChatPhoto implements TypeInterface
{
	/** @var string */
	public string $smallFileId;

	/** @var string */
	public string $smallFileUniqueId;

	/** @var string */
	public string $bigFileId;

	/** @var string */
	public string $bigFileUniqueId;
}
