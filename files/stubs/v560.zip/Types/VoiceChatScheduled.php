<?php

namespace TelegramApi\Types;

class VoiceChatScheduled implements TypeInterface
{
	/** @var int Point in time (Unix timestamp) when the voice chat is supposed to be started by a chat administrator */
	public int $startDate;
}
