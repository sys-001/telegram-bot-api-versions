<?php

namespace TelegramApi\Types;

class BotCommandScopeAllChatAdministrators extends BotCommandScope
{
	/** @var string */
	public string $type;
}
