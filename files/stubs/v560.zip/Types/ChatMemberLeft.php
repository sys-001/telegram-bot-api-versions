<?php

namespace TelegramApi\Types;

class ChatMemberLeft extends ChatMember
{
	/** @var string */
	public string $status;

	/** @var User */
	public User $user;
}
