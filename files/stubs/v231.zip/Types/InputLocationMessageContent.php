<?php

namespace TelegramApi\Types;

class InputLocationMessageContent extends InputMessageContent
{
	/** @var float */
	public float $latitude;

	/** @var float */
	public float $longitude;
}
