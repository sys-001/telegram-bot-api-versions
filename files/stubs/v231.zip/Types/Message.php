<?php

namespace TelegramApi\Types;

class Message implements TypeInterface
{
	/** @var int */
	public int $messageId;

	/** @var User|null */
	public ?User $from = null;

	/** @var int */
	public int $date;

	/** @var Chat */
	public Chat $chat;

	/** @var User|null */
	public ?User $forwardFrom = null;

	/** @var Chat|null */
	public ?Chat $forwardFromChat = null;

	/** @var int|null */
	public ?int $forwardFromMessageId = null;

	/** @var int|null */
	public ?int $forwardDate = null;

	/** @var Message|null */
	public ?Message $replyToMessage = null;

	/** @var int|null */
	public ?int $editDate = null;

	/** @var string|null */
	public ?string $text = null;

	/** @var Array<MessageEntity>|null */
	public ?array $entities = null;

	/** @var Audio|null */
	public ?Audio $audio = null;

	/** @var Document|null */
	public ?Document $document = null;

	/** @var Game|null */
	public ?Game $game = null;

	/** @var Array<PhotoSize>|null */
	public ?array $photo = null;

	/** @var Sticker|null */
	public ?Sticker $sticker = null;

	/** @var Video|null */
	public ?Video $video = null;

	/** @var Voice|null */
	public ?Voice $voice = null;

	/** @var string|null */
	public ?string $caption = null;

	/** @var Contact|null */
	public ?Contact $contact = null;

	/** @var Location|null */
	public ?Location $location = null;

	/** @var Venue|null */
	public ?Venue $venue = null;

	/** @var User|null */
	public ?User $newChatMember = null;

	/** @var User|null */
	public ?User $leftChatMember = null;

	/** @var string|null */
	public ?string $newChatTitle = null;

	/** @var Array<PhotoSize>|null */
	public ?array $newChatPhoto = null;

	/** @var bool|null */
	public ?bool $deleteChatPhoto = null;

	/** @var bool|null */
	public ?bool $groupChatCreated = null;

	/** @var bool|null */
	public ?bool $supergroupChatCreated = null;

	/** @var bool|null */
	public ?bool $channelChatCreated = null;

	/** @var int|null */
	public ?int $migrateToChatId = null;

	/** @var int|null */
	public ?int $migrateFromChatId = null;

	/** @var Message|null */
	public ?Message $pinnedMessage = null;
}
