<?php

namespace TelegramApi\Types;

class Location implements TypeInterface
{
	/** @var float */
	public float $longitude;

	/** @var float */
	public float $latitude;
}
