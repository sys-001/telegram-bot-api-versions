<?php

namespace TelegramApi\Types;

abstract class InputMessageContent implements TypeInterface
{
}
