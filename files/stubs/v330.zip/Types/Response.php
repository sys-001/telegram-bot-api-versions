<?php

namespace TelegramApi\Types;

class Response implements TypeInterface
{
	public bool $ok;
	public mixed $result = null;
	public ?int $errorCode = null;
	public ?string $description = null;
}
