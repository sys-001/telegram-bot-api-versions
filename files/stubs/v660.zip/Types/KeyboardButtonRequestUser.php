<?php

namespace TelegramApi\Types;

class KeyboardButtonRequestUser implements TypeInterface
{
	/** @var int Signed 32-bit identifier of the request, which will be received back in the UserShared object. Must be unique within the message */
	public int $requestId;

	/** @var bool|null Optional. Pass True to request a bot, pass False to request a regular user. If not specified, no additional restrictions are applied. */
	public ?bool $userIsBot = null;

	/** @var bool|null Optional. Pass True to request a premium user, pass False to request a non-premium user. If not specified, no additional restrictions are applied. */
	public ?bool $userIsPremium = null;
}
