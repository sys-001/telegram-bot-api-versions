<?php

namespace TelegramApi\Types;

class GeneralForumTopicHidden implements TypeInterface
{
}
