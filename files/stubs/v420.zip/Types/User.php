<?php

namespace TelegramApi\Types;

class User implements TypeInterface
{
	/** @var int Unique identifier for this user or bot */
	public int $id;

	/** @var bool True, if this user is a bot */
	public bool $isBot;

	/** @var string User‘s or bot’s first name */
	public string $firstName;

	/** @var string|null Optional. User‘s or bot’s last name */
	public ?string $lastName = null;

	/** @var string|null Optional. User‘s or bot’s username */
	public ?string $username = null;

	/** @var string|null Optional. IETF language tag of the user's language */
	public ?string $languageCode = null;
}
