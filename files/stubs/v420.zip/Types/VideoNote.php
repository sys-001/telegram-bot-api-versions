<?php

namespace TelegramApi\Types;

class VideoNote implements TypeInterface
{
	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Video width and height (diameter of the video message) as defined by sender */
	public int $length;

	/** @var int Duration of the video in seconds as defined by sender */
	public int $duration;

	/** @var PhotoSize|null Optional. Video thumbnail */
	public ?PhotoSize $thumb = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
