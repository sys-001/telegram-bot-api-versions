<?php

namespace TelegramApi\Types;

class Poll implements TypeInterface
{
	/** @var string Unique poll identifier */
	public string $id;

	/** @var string Poll question, 1-255 characters */
	public string $question;

	/** @var Array<PollOption> List of poll options */
	public array $options;

	/** @var bool True, if the poll is closed */
	public bool $isClosed;
}
