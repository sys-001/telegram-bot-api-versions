<?php

namespace TelegramApi\Types;

class ChatMemberOwner extends ChatMember
{
	/** @var string */
	public string $status;

	/** @var User */
	public User $user;

	/** @var string */
	public string $customTitle;

	/** @var bool */
	public bool $isAnonymous;
}
