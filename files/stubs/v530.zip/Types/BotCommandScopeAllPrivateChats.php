<?php

namespace TelegramApi\Types;

class BotCommandScopeAllPrivateChats extends BotCommandScope
{
	/** @var string */
	public string $type;
}
