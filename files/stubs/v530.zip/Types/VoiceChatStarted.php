<?php

namespace TelegramApi\Types;

class VoiceChatStarted implements TypeInterface
{
}
