<?php

namespace TelegramApi\Types;

class VoiceChatScheduled implements TypeInterface
{
	/** @var int */
	public int $startDate;
}
