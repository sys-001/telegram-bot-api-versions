<?php

namespace TelegramApi\Types;

abstract class InputMedia implements TypeInterface
{
}
