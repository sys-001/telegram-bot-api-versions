<?php

namespace TelegramApi\Types;

class VideoNote implements TypeInterface
{
	/** @var string */
	public string $fileId;

	/** @var string */
	public string $fileUniqueId;

	/** @var int */
	public int $length;

	/** @var int */
	public int $duration;

	/** @var PhotoSize|null */
	public ?PhotoSize $thumb = null;

	/** @var int|null */
	public ?int $fileSize = null;
}
