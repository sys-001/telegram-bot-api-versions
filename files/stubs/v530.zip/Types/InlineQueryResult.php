<?php

namespace TelegramApi\Types;

abstract class InlineQueryResult implements TypeInterface
{
}
