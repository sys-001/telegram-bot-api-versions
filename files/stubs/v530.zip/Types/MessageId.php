<?php

namespace TelegramApi\Types;

class MessageId implements TypeInterface
{
	/** @var int */
	public int $messageId;
}
