<?php

namespace TelegramApi\Types;

class InputLocationMessageContent extends InputMessageContent
{
	/** @var Type Description */
	public Type $field;

	/** @var float Latitude of the location in degrees */
	public float $latitude;

	/** @var float Longitude of the location in degrees */
	public float $longitude;
}
