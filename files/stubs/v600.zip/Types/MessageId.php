<?php

namespace TelegramApi\Types;

class MessageId implements TypeInterface
{
	/** @var int Unique message identifier */
	public int $messageId;
}
