<?php

namespace TelegramApi\Types;

class File implements TypeInterface
{
	/** @var string Identifier for this file, which can be used to download or reuse the file */
	public string $fileId;

	/** @var string Unique identifier for this file, which is supposed to be the same over time and for different bots. Can't be used to download or reuse the file. */
	public string $fileUniqueId;

	/** @var int|null Optional. File size in bytes, if known */
	public ?int $fileSize = null;

	/** @var string|null Optional. File path. Use https://api.telegram.org/file/bot<token>/<file_path> to get the file. */
	public ?string $filePath = null;
}
