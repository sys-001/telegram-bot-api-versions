<?php

namespace TelegramApi\Types;

class Dice implements TypeInterface
{
	/** @var int */
	public int $value;
}
