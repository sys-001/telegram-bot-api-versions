<?php

namespace TelegramApi\Types;

class Dice implements TypeInterface
{
	/** @var int Value of the dice, 1-6 */
	public int $value;
}
