<?php

namespace TelegramApi\Types;

class CallbackGame implements TypeInterface
{
}
