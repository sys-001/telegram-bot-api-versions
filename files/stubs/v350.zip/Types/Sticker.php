<?php

namespace TelegramApi\Types;

class Sticker implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var string Unique identifier for this file */
	public string $fileId;

	/** @var int Sticker width */
	public int $width;

	/** @var int Sticker height */
	public int $height;

	/** @var PhotoSize|null Optional. Sticker thumbnail in the .webp or .jpg format */
	public ?PhotoSize $thumb = null;

	/** @var string|null Optional. Emoji associated with the sticker */
	public ?string $emoji = null;

	/** @var string|null Optional. Name of the sticker set to which the sticker belongs */
	public ?string $setName = null;

	/** @var MaskPosition|null Optional. For mask stickers, the position where the mask should be placed */
	public ?MaskPosition $maskPosition = null;

	/** @var int|null Optional. File size */
	public ?int $fileSize = null;
}
