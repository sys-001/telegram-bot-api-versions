<?php

namespace TelegramApi\Types;

class Message implements TypeInterface
{
	/** @var Type Description */
	public Type $field;

	/** @var int Unique message identifier inside this chat */
	public int $messageId;

	/** @var User|null Optional. Sender, empty for messages sent to channels */
	public ?User $from = null;

	/** @var int Date the message was sent in Unix time */
	public int $date;

	/** @var Chat Conversation the message belongs to */
	public Chat $chat;

	/** @var User|null Optional. For forwarded messages, sender of the original message */
	public ?User $forwardFrom = null;

	/** @var Chat|null Optional. For messages forwarded from channels, information about the original channel */
	public ?Chat $forwardFromChat = null;

	/** @var int|null Optional. For messages forwarded from channels, identifier of the original message in the channel */
	public ?int $forwardFromMessageId = null;

	/** @var string|null Optional. For messages forwarded from channels, signature of the post author if present */
	public ?string $forwardSignature = null;

	/** @var int|null Optional. For forwarded messages, date the original message was sent in Unix time */
	public ?int $forwardDate = null;

	/** @var Message|null Optional. For replies, the original message. Note that the Message object in this field will not contain further reply_to_message fields even if it itself is a reply. */
	public ?Message $replyToMessage = null;

	/** @var int|null Optional. Date the message was last edited in Unix time */
	public ?int $editDate = null;

	/** @var string|null Optional. The unique identifier of a media message group this message belongs to */
	public ?string $mediaGroupId = null;

	/** @var string|null Optional. Signature of the post author for messages in channels */
	public ?string $authorSignature = null;

	/** @var string|null Optional. For text messages, the actual UTF-8 text of the message, 0-4096 characters. */
	public ?string $text = null;

	/** @var Array<MessageEntity>|null Optional. For text messages, special entities like usernames, URLs, bot commands, etc. that appear in the text */
	public ?array $entities = null;

	/** @var Array<MessageEntity>|null Optional. For messages with a caption, special entities like usernames, URLs, bot commands, etc. that appear in the caption */
	public ?array $captionEntities = null;

	/** @var Audio|null Optional. Message is an audio file, information about the file */
	public ?Audio $audio = null;

	/** @var Document|null Optional. Message is a general file, information about the file */
	public ?Document $document = null;

	/** @var Game|null Optional. Message is a game, information about the game. More about games » */
	public ?Game $game = null;

	/** @var Array<PhotoSize>|null Optional. Message is a photo, available sizes of the photo */
	public ?array $photo = null;

	/** @var Sticker|null Optional. Message is a sticker, information about the sticker */
	public ?Sticker $sticker = null;

	/** @var Video|null Optional. Message is a video, information about the video */
	public ?Video $video = null;

	/** @var Voice|null Optional. Message is a voice message, information about the file */
	public ?Voice $voice = null;

	/** @var VideoNote|null Optional. Message is a video note, information about the video message */
	public ?VideoNote $videoNote = null;

	/** @var string|null Optional. Caption for the audio, document, photo, video or voice, 0-200 characters */
	public ?string $caption = null;

	/** @var Contact|null Optional. Message is a shared contact, information about the contact */
	public ?Contact $contact = null;

	/** @var Location|null Optional. Message is a shared location, information about the location */
	public ?Location $location = null;

	/** @var Venue|null Optional. Message is a venue, information about the venue */
	public ?Venue $venue = null;

	/** @var Array<User>|null Optional. New members that were added to the group or supergroup and information about them (the bot itself may be one of these members) */
	public ?array $newChatMembers = null;

	/** @var User|null Optional. A member was removed from the group, information about them (this member may be the bot itself) */
	public ?User $leftChatMember = null;

	/** @var string|null Optional. A chat title was changed to this value */
	public ?string $newChatTitle = null;

	/** @var Array<PhotoSize>|null Optional. A chat photo was change to this value */
	public ?array $newChatPhoto = null;

	/** @var bool|null Optional. Service message: the chat photo was deleted */
	public ?bool $deleteChatPhoto = true;

	/** @var bool|null Optional. Service message: the group has been created */
	public ?bool $groupChatCreated = true;

	/** @var bool|null Optional. Service message: the supergroup has been created. This field can‘t be received in a message coming through updates, because bot can’t be a member of a supergroup when it is created. It can only be found in reply_to_message if someone replies to a very first message in a directly created supergroup. */
	public ?bool $supergroupChatCreated = true;

	/** @var bool|null Optional. Service message: the channel has been created. This field can‘t be received in a message coming through updates, because bot can’t be a member of a channel when it is created. It can only be found in reply_to_message if someone replies to a very first message in a channel. */
	public ?bool $channelChatCreated = true;

	/** @var int|null Optional. The group has been migrated to a supergroup with the specified identifier. This number may be greater than 32 bits and some programming languages may have difficulty/silent defects in interpreting it. But it is smaller than 52 bits, so a signed 64 bit integer or double-precision float type are safe for storing this identifier. */
	public ?int $migrateToChatId = null;

	/** @var int|null Optional. The supergroup has been migrated from a group with the specified identifier. This number may be greater than 32 bits and some programming languages may have difficulty/silent defects in interpreting it. But it is smaller than 52 bits, so a signed 64 bit integer or double-precision float type are safe for storing this identifier. */
	public ?int $migrateFromChatId = null;

	/** @var Message|null Optional. Specified message was pinned. Note that the Message object in this field will not contain further reply_to_message fields even if it is itself a reply. */
	public ?Message $pinnedMessage = null;

	/** @var Invoice|null Optional. Message is an invoice for a payment, information about the invoice. More about payments » */
	public ?Invoice $invoice = null;

	/** @var SuccessfulPayment|null Optional. Message is a service message about a successful payment, information about the payment. More about payments » */
	public ?SuccessfulPayment $successfulPayment = null;
}
