<?php

namespace TelegramApi\Types;

class InputMediaVideo extends InputMedia
{
	/** @var Type Description */
	public Type $field;

	/** @var string Type of the result, must be video */
	public string $type = 'video';

	/** @var string File to send. Pass a file_id to send a file that exists on the Telegram servers (recommended), pass an HTTP URL for Telegram to get a file from the Internet, or pass "attach://<file_attach_name>" to upload a new one using multipart/form-data under <file_attach_name> name. More info on Sending Files » */
	public string $media;

	/** @var string|null Optional. Caption of the video to be sent, 0-200 characters */
	public ?string $caption = null;

	/** @var int|null Optional. Video width */
	public ?int $width = null;

	/** @var int|null Optional. Video height */
	public ?int $height = null;

	/** @var int|null Optional. Video duration */
	public ?int $duration = null;
}
